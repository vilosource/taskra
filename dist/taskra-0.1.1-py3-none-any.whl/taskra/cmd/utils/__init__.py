"""Utility functions for the CLI."""
